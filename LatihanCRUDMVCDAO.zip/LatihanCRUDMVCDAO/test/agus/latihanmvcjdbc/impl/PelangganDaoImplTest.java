/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agus.latihanmvcjdbc.impl;

import agus.latihanmvcjdbc.entity.Pelanggan;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class PelangganDaoImplTest {
    
    public PelangganDaoImplTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testSomeMethod() {
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertPelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testInsertPelanggan() throws Exception {
        System.out.println("insertPelanggan");
        Pelanggan pelanggan = null;
        PelangganDaoImpl instance = null;
        instance.insertPelanggan(pelanggan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updatePelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testUpdatePelanggan() throws Exception {
        System.out.println("updatePelanggan");
        Pelanggan pelanggan = null;
        PelangganDaoImpl instance = null;
        instance.updatePelanggan(pelanggan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deletePelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testDeletePelanggan() throws Exception {
        System.out.println("deletePelanggan");
        Integer id = null;
        PelangganDaoImpl instance = null;
        instance.deletePelanggan(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testGetPelanggan_Integer() throws Exception {
        System.out.println("getPelanggan");
        Integer id = null;
        PelangganDaoImpl instance = null;
        Pelanggan expResult = null;
        Pelanggan result = instance.getPelanggan(id);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testGetPelanggan_String() throws Exception {
        System.out.println("getPelanggan");
        String email = "";
        PelangganDaoImpl instance = null;
        Pelanggan expResult = null;
        Pelanggan result = instance.getPelanggan(email);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selectAllPelanggan method, of class PelangganDaoImpl.
     */
    @Test
    public void testSelectAllPelanggan() throws Exception {
        System.out.println("selectAllPelanggan");
        PelangganDaoImpl instance = null;
        List<Pelanggan> expResult = null;
        List<Pelanggan> result = instance.selectAllPelanggan();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
